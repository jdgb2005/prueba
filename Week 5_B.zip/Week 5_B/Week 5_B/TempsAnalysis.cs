﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;  // Adding IO Class

namespace Week_5_B
{
    public partial class tempAnalysis : Form
    {
        public tempAnalysis()
        {
            InitializeComponent();

            startingAnalysis(); 
        }

        private string[,] startingAnalysis() // Creating 2D String

        {
            
            String[,] knownValues = new String[11, 2];
            knownValues[0, 0] = "Animal";
            knownValues[0, 1] = "NormalValue";

            knownValues[1, 0] = "Zebra";
            knownValues[1, 1] = "129.5";

            knownValues[2, 0] = "Unicorn";
            knownValues[2, 1] = "54.9";

            knownValues[3, 0] = "Platypus";
            knownValues[3, 1] = "12.19";

            knownValues[4, 0] = "Dragon";
            knownValues[4, 1] = "999.98";

            knownValues[5, 0] = "Elephant";
            knownValues[5, 1] = "103.66";

            knownValues[6, 0] = "Manticore";
            knownValues[6, 1] = ".035";

            knownValues[7, 0] = "Duck";
            knownValues[7, 1] = "1.34";

            knownValues[8, 0] = "Basilisk";
            knownValues[8, 1] = "45.2";

            knownValues[9, 0] = "Sphinx";
            knownValues[9, 1] = "8.00";

            knownValues[10, 0] = "Tiger";
            knownValues[10, 1] = "3.21";

          

            return knownValues;

        }

        private void clear() // Clear method
        {
            foreach (Control ctr in this.Controls) //Clearing content in text boxes and list boxes
            {
                if (ctr is TextBox)
                {
                    ctr.Text = "";
                }

                if (ctr is ListBox)
                {
                    ((ListBox)ctr).Items.Clear();
                }
            }

            nameAnimalLbl.Text = "Animal";
            normLbl.Text = "0";
            CountMaxLbl.Text = "0";
            CountNormLbl.Text = "0";
            CountMinLbl.Text = "0";
        }

        private Double getNormalValue(String name) //Method to get normal Temp for name
        {
            String[,] knownValues = new String[11, 2];
            knownValues = startingAnalysis();
            int n = 0, m = 1;
            Double normalValue = 0;

            for (n = 0; n < 11; n++)
            {
                if (knownValues[n, 0] != "" && knownValues[n, 0] == name)
                {
                    nameAnimalLbl.Text = name;
                    normalValue = Double.Parse(knownValues[n, m]);
                    return normalValue;
                }
            }

            return normalValue;
        }

        private void ReadFile(string path) //Method to load temps from file
        {
            double[] animals = new double[1000];
            double normalValue = 0;
            int m = 0;
            String lineR;

            TextReader loadT = new StreamReader(path);

            try   // Data validation for empty files and invalid names with warning messages
            {
                lineR = loadT.ReadLine();
            }
            catch (Exception)
            {
                MessageBox.Show("Cannot read file", "Invalid data", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (lineR == null)
            {
                MessageBox.Show("Empty File", "Invalid data", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (lineR != null)
            {
                normalValue = getNormalValue(lineR);
            }
            if (normalValue == 0)
            {
                MessageBox.Show("Animal name not available", "Invalid data", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            m = 0;

            lineR = loadT.ReadLine();

            while (lineR != null)
            {
                try
                {
                    animals[m] = Double.Parse(lineR);
                    lineR = loadT.ReadLine();
                    m++;
                }
                catch (Exception)
                {
                    MessageBox.Show("Error while loading data", "Invalid file", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    loadT.Close();
                    return;
                }
            }

            loadT.Close();

            List<Double> listMax = new List<Double>();    ///Creating lists for Max, min and normal temps
            List<Double> listNormal = new List<Double>();
            List<Double> listMin = new List<Double>();


            try
            {
                for (m = 0; m < animals.Length; m++) //Adding values to correspondent list boxes
                {
                    if (animals[m] > 0)
                    {
                        if (animals[m] > normalValue)
                        {
                            listMax.Add(animals[m]);
                        }
                        else if (animals[m] == normalValue)
                        {
                            listNormal.Add(animals[m]);
                        }
                        else if (animals[m] < normalValue)
                        {
                            listMin.Add(animals[m]);
                        }

                        

                    }
                }
            }
            catch (Exception)  //Data validation
            {

                MessageBox.Show("Error showing data", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            IEnumerable<Double> listMaxOrd = listMax.OrderBy(o => o); //Sorting values from high to low or opposite
            foreach (Double value in listMaxOrd)
            {
                listMaxTxBx.Items.Add(value);
            }
          
            CountMaxLbl.Text = listMax.Count().ToString();

            normLbl.Text = normalValue.ToString();
            CountNormLbl.Text = listNormal.Count().ToString();

            IEnumerable<Double> listMinOrd = listMin.OrderByDescending(o => o);
            foreach (Double value in listMinOrd)
            {
                listMinTxBx.Items.Add(value);
            }
            CountMinLbl.Text = listMin.Count().ToString();
        }

        private void loadBttn_Click(object sender, EventArgs e) // opening file method, defining path, file type
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog

            {
                InitialDirectory = @"C:\",
                Title = "Open Temps Text Files",

                CheckFileExists = false,
                CheckPathExists = false,

                DefaultExt = "txt",
                Filter = "txt files (*.txt)|*.txt",
                FilterIndex = 2,
                RestoreDirectory = true,

                ReadOnlyChecked = true,
                ShowReadOnly = true
            };

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                clear();
                ReadFile(openFileDialog1.FileName);
            }
            else //Warning message if file does not open
            {
                MessageBox.Show("File did not load", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
        }

        private void clearBtnn_Click(object sender, EventArgs e) //Clear button
        {
           
                clear();
            
        }

        private void closeBttn_Click(object sender, EventArgs e) //Close program button
        {
            this.Close();
        }
    }
}
