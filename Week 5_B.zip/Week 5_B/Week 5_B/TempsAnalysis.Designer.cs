﻿namespace Week_5_B
{
    partial class tempAnalysis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.loadBttn = new System.Windows.Forms.Button();
            this.clearBtnn = new System.Windows.Forms.Button();
            this.closeBttn = new System.Windows.Forms.Button();
            this.nameAnimalLbl = new System.Windows.Forms.Label();
            this.normLbl = new System.Windows.Forms.Label();
            this.CountMaxLbl = new System.Windows.Forms.Label();
            this.CountNormLbl = new System.Windows.Forms.Label();
            this.CountMinLbl = new System.Windows.Forms.Label();
            this.listMaxTxBx = new System.Windows.Forms.ListBox();
            this.listMinTxBx = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // loadBttn
            // 
            this.loadBttn.AutoSize = true;
            this.loadBttn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loadBttn.Location = new System.Drawing.Point(172, 205);
            this.loadBttn.Name = "loadBttn";
            this.loadBttn.Size = new System.Drawing.Size(93, 30);
            this.loadBttn.TabIndex = 0;
            this.loadBttn.Text = "Load File";
            this.loadBttn.UseVisualStyleBackColor = true;
            this.loadBttn.Click += new System.EventHandler(this.loadBttn_Click);
            // 
            // clearBtnn
            // 
            this.clearBtnn.AutoSize = true;
            this.clearBtnn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearBtnn.Location = new System.Drawing.Point(77, 268);
            this.clearBtnn.Name = "clearBtnn";
            this.clearBtnn.Size = new System.Drawing.Size(121, 30);
            this.clearBtnn.TabIndex = 1;
            this.clearBtnn.Text = "Clear Values";
            this.clearBtnn.UseVisualStyleBackColor = true;
            this.clearBtnn.Click += new System.EventHandler(this.clearBtnn_Click);
            // 
            // closeBttn
            // 
            this.closeBttn.AutoSize = true;
            this.closeBttn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.closeBttn.Location = new System.Drawing.Point(247, 268);
            this.closeBttn.Name = "closeBttn";
            this.closeBttn.Size = new System.Drawing.Size(136, 30);
            this.closeBttn.TabIndex = 2;
            this.closeBttn.Text = "Close Program";
            this.closeBttn.UseVisualStyleBackColor = true;
            this.closeBttn.Click += new System.EventHandler(this.closeBttn_Click);
            // 
            // nameAnimalLbl
            // 
            this.nameAnimalLbl.AutoSize = true;
            this.nameAnimalLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameAnimalLbl.Location = new System.Drawing.Point(192, 41);
            this.nameAnimalLbl.Name = "nameAnimalLbl";
            this.nameAnimalLbl.Size = new System.Drawing.Size(63, 20);
            this.nameAnimalLbl.TabIndex = 3;
            this.nameAnimalLbl.Text = "Animal";
            // 
            // normLbl
            // 
            this.normLbl.AutoSize = true;
            this.normLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.normLbl.Location = new System.Drawing.Point(214, 70);
            this.normLbl.Name = "normLbl";
            this.normLbl.Size = new System.Drawing.Size(19, 20);
            this.normLbl.TabIndex = 4;
            this.normLbl.Text = "0";
            // 
            // CountMaxLbl
            // 
            this.CountMaxLbl.AutoSize = true;
            this.CountMaxLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CountMaxLbl.Location = new System.Drawing.Point(90, 182);
            this.CountMaxLbl.Name = "CountMaxLbl";
            this.CountMaxLbl.Size = new System.Drawing.Size(19, 20);
            this.CountMaxLbl.TabIndex = 5;
            this.CountMaxLbl.Text = "0";
            // 
            // CountNormLbl
            // 
            this.CountNormLbl.AutoSize = true;
            this.CountNormLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CountNormLbl.Location = new System.Drawing.Point(214, 126);
            this.CountNormLbl.Name = "CountNormLbl";
            this.CountNormLbl.Size = new System.Drawing.Size(19, 20);
            this.CountNormLbl.TabIndex = 6;
            this.CountNormLbl.Text = "0";
            // 
            // CountMinLbl
            // 
            this.CountMinLbl.AutoSize = true;
            this.CountMinLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CountMinLbl.Location = new System.Drawing.Point(348, 182);
            this.CountMinLbl.Name = "CountMinLbl";
            this.CountMinLbl.Size = new System.Drawing.Size(19, 20);
            this.CountMinLbl.TabIndex = 7;
            this.CountMinLbl.Text = "0";
            // 
            // listMaxTxBx
            // 
            this.listMaxTxBx.FormattingEnabled = true;
            this.listMaxTxBx.Location = new System.Drawing.Point(39, 70);
            this.listMaxTxBx.Name = "listMaxTxBx";
            this.listMaxTxBx.Size = new System.Drawing.Size(120, 95);
            this.listMaxTxBx.TabIndex = 8;
            // 
            // listMinTxBx
            // 
            this.listMinTxBx.FormattingEnabled = true;
            this.listMinTxBx.Location = new System.Drawing.Point(297, 70);
            this.listMinTxBx.Name = "listMinTxBx";
            this.listMinTxBx.Size = new System.Drawing.Size(120, 95);
            this.listMinTxBx.TabIndex = 9;
            // 
            // tempAnalysis
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(452, 314);
            this.Controls.Add(this.listMinTxBx);
            this.Controls.Add(this.listMaxTxBx);
            this.Controls.Add(this.CountMinLbl);
            this.Controls.Add(this.CountNormLbl);
            this.Controls.Add(this.CountMaxLbl);
            this.Controls.Add(this.normLbl);
            this.Controls.Add(this.nameAnimalLbl);
            this.Controls.Add(this.closeBttn);
            this.Controls.Add(this.clearBtnn);
            this.Controls.Add(this.loadBttn);
            this.Name = "tempAnalysis";
            this.Text = "Temps Analysis";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button loadBttn;
        private System.Windows.Forms.Button clearBtnn;
        private System.Windows.Forms.Button closeBttn;
        private System.Windows.Forms.Label nameAnimalLbl;
        private System.Windows.Forms.Label normLbl;
        private System.Windows.Forms.Label CountMaxLbl;
        private System.Windows.Forms.Label CountNormLbl;
        private System.Windows.Forms.Label CountMinLbl;
        private System.Windows.Forms.ListBox listMaxTxBx;
        private System.Windows.Forms.ListBox listMinTxBx;
    }
}

